MSG.catCarPackage = "MoonCar 自走车";
MSG.catCarTracker = "循迹车";
MSG.catToyCar = "玩具车";
MSG.catCarButton = "按钮开关";
MSG.catUltrasonic = "超音波";
MSG.catIR = "红外线";
MSG.catWS2812 = "全彩灯条";
