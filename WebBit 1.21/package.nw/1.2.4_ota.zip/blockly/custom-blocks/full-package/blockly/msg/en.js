MSG.catFullPackage = "Extension Package";
