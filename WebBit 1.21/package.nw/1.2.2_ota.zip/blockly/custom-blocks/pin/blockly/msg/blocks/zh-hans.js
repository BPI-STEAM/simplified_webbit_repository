Blockly.Msg.WEBDUINO_PIN_READ = "读取脚位";
Blockly.Msg.WEBDUINO_PIN_ANALOG_WRITE = "类比输出 ( PWM ) 至脚位";
Blockly.Msg.WEBDUINO_PIN_DIGITAL_WRITE = "数位输出至脚位";
Blockly.Msg.WEBDUINO_PIN_VALUE = "数值";
Blockly.Msg.WEBDUINO_PIN_DIN = "数位输入";;
Blockly.Msg.WEBDUINO_PIN_AIN = "类比输入";
