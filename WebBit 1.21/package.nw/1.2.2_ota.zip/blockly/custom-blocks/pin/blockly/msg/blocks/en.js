Blockly.Msg.WEBDUINO_PIN_READ = "Read Value from";
Blockly.Msg.WEBDUINO_PIN_ANALOG_WRITE = "Analog Output (PWM) to Pin";
Blockly.Msg.WEBDUINO_PIN_DIGITAL_WRITE = "Digital Output to Pin";
Blockly.Msg.WEBDUINO_PIN_VALUE = "";
Blockly.Msg.WEBDUINO_PIN_DIN = "Digital Input";
Blockly.Msg.WEBDUINO_PIN_AIN = "Analog Input";
