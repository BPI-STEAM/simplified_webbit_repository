Blockly.Msg.WEBDUINO_PIN_READ = "讀取腳位";
Blockly.Msg.WEBDUINO_PIN_ANALOG_WRITE = "類比輸出 ( PWM ) 至腳位";
Blockly.Msg.WEBDUINO_PIN_DIGITAL_WRITE = "數位輸出至腳位";
Blockly.Msg.WEBDUINO_PIN_VALUE = "數值";
Blockly.Msg.WEBDUINO_PIN_DIN = "數位輸入";
Blockly.Msg.WEBDUINO_PIN_AIN = "類比輸入";
