MSG.catPin = "I/O 引腳";
