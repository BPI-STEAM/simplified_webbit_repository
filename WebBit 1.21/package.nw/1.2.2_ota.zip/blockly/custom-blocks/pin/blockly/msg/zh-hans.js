MSG.catPin = "I/O 引脚";
