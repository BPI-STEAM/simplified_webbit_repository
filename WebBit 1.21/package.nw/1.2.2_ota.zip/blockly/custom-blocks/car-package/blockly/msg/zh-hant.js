MSG.catCarPackage = "MoonCar 自走車";
MSG.catCarTracker = "循跡車";
MSG.catToyCar = "玩具車";
MSG.catCarButton = "按鈕開關";
MSG.catUltrasonic = "超音波";
MSG.catIR = "紅外線";
MSG.catWS2812 = "全彩燈條";
