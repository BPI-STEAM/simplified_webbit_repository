// CarTracker
Blockly.Msg.WEBDUINO_CARTRACKER_INDUCTION = "當循跡偵測訊號為";
Blockly.Msg.WEBDUINO_CARTRACKER_MOTION = "時，動作";
Blockly.Msg.WEBDUINO_CARTRACKER_DO = "執行";
Blockly.Msg.WEBDUINO_CARTRACKER_ON = "啟動循跡";
Blockly.Msg.WEBDUINO_CARTRACKER_OFF = "停止循跡";
Blockly.Msg.WEBDUINO_CARTRACKER_STOP = "停止";
Blockly.Msg.WEBDUINO_CARTRACKER_FORWARD = "前進";
Blockly.Msg.WEBDUINO_CARTRACKER_TURN_LEFT = "原地左轉";
Blockly.Msg.WEBDUINO_CARTRACKER_TURN_RIGHT = "原地右轉";
Blockly.Msg.WEBDUINO_CARTRACKER_BACK = "後退";
Blockly.Msg.WEBDUINO_CARTRACKER_TURN_LEFT_SLOWLY= "原地慢速左轉";
Blockly.Msg.WEBDUINO_CARTRACKER_TURN_RIGHT_SLOWLY = "原地慢速右轉";
Blockly.Msg.WEBDUINO_CARTRACKER_LEFT_FORWARD = "左前";
Blockly.Msg.WEBDUINO_CARTRACKER_RIGHT_FORWARD = "右前";
Blockly.Msg.WEBDUINO_CARTRACKER_LEFT_BACK = "左後";
Blockly.Msg.WEBDUINO_CARTRACKER_RIGHT_BACK = "右後";

Blockly.Msg.WEBDUINO_TOYCAR = "自走車動作";
Blockly.Msg.WEBDUINO_TOYCAR_GOFRONT = "前進";
Blockly.Msg.WEBDUINO_TOYCAR_GOBACK = "後退";
Blockly.Msg.WEBDUINO_TOYCAR_GOLEFT = "左前";
Blockly.Msg.WEBDUINO_TOYCAR_GORIGHT = "右前";
Blockly.Msg.WEBDUINO_TOYCAR_STOP = "停止";

Blockly.Msg.WEBDUINO_CARBUTTON_EVENT_WHEN = "當小車按鈕被";

Blockly.Msg.WEBDUINO_ULTRASONIC_DISTANCE = "超音波傳感器所擷取的距離 ( 公分 )";

Blockly.Msg.WEBDUINO_IRRECV_ON = "紅外線開始接收訊號";
Blockly.Msg.WEBDUINO_IRRECV_DO = "執行";
Blockly.Msg.WEBDUINO_IRRECV_CODE = "紅外線接收的代碼";
Blockly.Msg.WEBDUINO_IRLED_LAUNCHCODE = "紅外線發射代碼 ( 十六進位 )";

Blockly.Msg.WEBDUINO_WS2812_LED_SET = "設定燈環第";
Blockly.Msg.WEBDUINO_WS2812_LED_COLOR = "顆顏色為";
Blockly.Msg.WEBDUINO_WS2812_DISPLAY = "顯示";
Blockly.Msg.WEBDUINO_WS2812_BRIGHTBESS = "設定燈環亮度 (0~127)";
Blockly.Msg.WEBDUINO_WS2812_CLOSE = "關閉燈環";
