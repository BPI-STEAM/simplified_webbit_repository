MSG.catCarPackage = "Moon Car";
MSG.catCarTracker = "Track Car";
MSG.catToyCar = "Toy Car";
MSG.catCarButton = "Button";
MSG.catUltrasonic = "Ultrasonic";
MSG.catIR = "IR";
MSG.catWS2812 = "WS2812 Matrix";
