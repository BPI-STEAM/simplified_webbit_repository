MSG.catBasicPackage = "基础套件包";
MSG.catIR = "红外线";
MSG.catSound = "声音侦测";
MSG.catUltrasonic = "超音波";
MSG.catServo = "伺服马达";
MSG.catPhotocell = "光敏(可变)电阻";
