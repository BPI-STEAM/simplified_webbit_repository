MSG.catBasicPackage = "Basic Package";
MSG.catIR = "IR";
MSG.catSound = "Sound Detection";
MSG.catUltrasonic = "Ultrasonic";
MSG.catServo = "Servo Motor";
MSG.catPhotocell = "Photocell";
