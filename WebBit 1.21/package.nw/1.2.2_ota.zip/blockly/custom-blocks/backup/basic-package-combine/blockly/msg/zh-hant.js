MSG.catBasicPackage = "基礎套件包";
MSG.catIR = "紅外線";
MSG.catSound = "聲音偵測";
MSG.catUltrasonic = "超音波";
MSG.catServo = "伺服馬達";
MSG.catPhotocell = "光敏(可變)電阻";
