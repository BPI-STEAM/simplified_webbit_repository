Blockly.Msg.WEBBIT_IRRECV_ON = "红外线接收 ( 脚位 1 )，开始接收信号";
Blockly.Msg.WEBBIT_IRRECV_DO = "运行";
Blockly.Msg.WEBBIT_IRRECV_CODE = "红外线接收的代码";
Blockly.Msg.WEBBIT_IRLED_LAUNCHCODE = "红外线发射 ( 脚位 2 )，发射代码 ( 十六进位 )";

Blockly.Msg.WEBDUINO_ULTRASONIC_NEW_TRIG = "超音波传感器，Trig";
Blockly.Msg.WEBDUINO_ULTRASONIC_NEW_ECHO = " Echo";
Blockly.Msg.WEBDUINO_ULTRASONIC_DISTANCE = "所截取的距离 ( 公分 )";

Blockly.Msg.WEBDUINO_SERVO = "伺服马达，脚位";
Blockly.Msg.WEBDUINO_SERVO_ANGLE = "旋转角度 ( 0-180 ) ";

Blockly.Msg.WEBDUINO_SOUND = "声音侦测传感器，脚位";
Blockly.Msg.WEBDUINO_SOUND_WHEN = "当";
Blockly.Msg.WEBDUINO_SOUND_STATUS_DETECTED = "有";
Blockly.Msg.WEBDUINO_SOUND_STATUS_ENDED = "没有";
Blockly.Msg.WEBDUINO_SOUND_DETECTED = "侦测到声音变化";
Blockly.Msg.WEBDUINO_SOUND_DO = "运行";

Blockly.Msg.WEBDUINO_PHOTOCELL = "光敏电阻";
Blockly.Msg.WEBDUINO_PHOTOCELL_UPPER_LEFT = "左上";
Blockly.Msg.WEBDUINO_PHOTOCELL_UPPER_RIGHT = "右上";
Blockly.Msg.WEBDUINO_PHOTOCELL_DETECTED = "开始侦测";
Blockly.Msg.WEBDUINO_PHOTOCELL_PIN = "光敏脚位";
Blockly.Msg.WEBDUINO_PHOTOCELL_DO = "运行";
Blockly.Msg.WEBDUINO_PHOTOCELL_VAL = "侦测的数值";
Blockly.Msg.WEBDUINO_PHOTOCELL_STOP = "停止侦测";
