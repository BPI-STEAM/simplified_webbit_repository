MSG.catBasicPackage = "基础套件包";
