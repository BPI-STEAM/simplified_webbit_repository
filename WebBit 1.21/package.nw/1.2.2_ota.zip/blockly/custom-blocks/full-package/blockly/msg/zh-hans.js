MSG.catFullPackage = "擴充套件包";
